require 'test_helper'

class IpTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
