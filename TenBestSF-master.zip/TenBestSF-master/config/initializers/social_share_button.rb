SocialShareButton.configure do |config|
  config.allow_sites = %w(twitter facebook google_plus linkedin weibo qq douban google_bookmark
                          delicious tumblr pinterest email wechat vkontakte
                          xing reddit hacker_news)
end
