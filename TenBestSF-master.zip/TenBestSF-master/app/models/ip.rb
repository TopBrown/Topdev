class Ip < ApplicationRecord
end
