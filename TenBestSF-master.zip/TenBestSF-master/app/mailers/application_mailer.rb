class ApplicationMailer < ActionMailer::Base
  default from: 'SF@10bestnetwork.com'
  layout 'mailer'
end
